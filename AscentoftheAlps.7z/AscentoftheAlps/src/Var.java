/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author 1mccubbinaid
 */
public class Var {
    
}
