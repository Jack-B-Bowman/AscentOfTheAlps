import javax.swing.JPanel;

public class AnimationWindow extends JPanel {

	/**
	 * Create the panel.
	 */
	public AnimationWindow() {

	}

}
